package com.lamune.sb154.gra_webinit.gra_webinit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GraWebinitApplication {

	public static void main(String[] args) {
		SpringApplication.run(GraWebinitApplication.class, args);
	}
}
